from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.properties import StringProperty, ListProperty
from kivy.uix.screenmanager import ScreenManager, Screen
from bitpin.market import Market
import threading

KV = r"""
#:import dp kivy.metrics.dp

ScreenManager:
    MainScreen:

<MainScreen>:
    name: "main"
    BoxLayout:
        orientation: "vertical"
        padding: dp(12)
        spacing: dp(10)

        Label:
            text: "Bitpin Trader"
            font_size: "24sp"
            bold: True
            size_hint_y: None
            height: dp(48)

        Label:
            text: root.status
            size_hint_y: None
            height: dp(32)

        BoxLayout:
            size_hint_y: None
            height: dp(48)
            spacing: dp(8)
            Button:
                text: "دریافت بازارها"
                on_release: root.load_markets()
            Button:
                text: "تیکرها"
                on_release: root.load_tickers()

        ScrollView:
            do_scroll_x: False
            Label:
                text: root.output
                text_size: self.width, None
                size_hint_y: None
                height: max(self.texture_size[1], dp(400))
                halign: "right"
                valign: "top"
                padding: dp(8), dp(8)
"""

class MainScreen(Screen):
    status = StringProperty("آماده")
    output = StringProperty("برای شروع، «دریافت بازارها» را بزنید.")
    market = None

    def on_pre_enter(self):
        self.market = Market()

    def load_markets(self):
        self.status = "در حال دریافت بازارها..."
        threading.Thread(target=self._fetch_markets, daemon=True).start()

    def _fetch_markets(self):
        try:
            data = self.market.get_markets()
            if isinstance(data, dict):
                items = data.get("results", data)
            else:
                items = data
            count = len(items) if hasattr(items, "__len__") else 0
            text = f"تعداد بازارها: {count}\n\n"
            if isinstance(items, list):
                for item in items[:40]:
                    if isinstance(item, dict):
                        symbol = item.get("symbol") or item.get("code") or item.get("title") or "?"
                        text += f"{symbol}\n"
                    else:
                        text += f"{item}\n"
            self._update(text, "بازارها دریافت شد")
        except Exception as e:
            self._update(f"خطا:\n{e}", "خطا")

    def load_tickers(self):
        self.status = "در حال دریافت قیمت‌ها..."
        threading.Thread(target=self._fetch_tickers, daemon=True).start()

    def _fetch_tickers(self):
        try:
            data = self.market.get_tickers()
            items = data.get("results", data) if isinstance(data, dict) else data
            text = ""
            if isinstance(items, list):
                for item in items[:50]:
                    if isinstance(item, dict):
                        symbol = item.get("symbol") or item.get("code") or "?"
                        price = item.get("last_price") or item.get("last") or item.get("price") or "?"
                        text += f"{symbol}  |  {price}\n"
                    else:
                        text += f"{item}\n"
            else:
                text = str(data)
            self._update(text or "داده‌ای دریافت نشد.", "تیکرها دریافت شد")
        except Exception as e:
            self._update(f"خطا:\n{e}", "خطا")

    def _update(self, output, status):
        def apply(_dt):
            self.output = output
            self.status = status
        Clock.schedule_once(apply, 0)

class BitpinTraderApp(App):
    title = "Bitpin Trader"
    def build(self):
        return Builder.load_string(KV)

if __name__ == "__main__":
    BitpinTraderApp().run()
