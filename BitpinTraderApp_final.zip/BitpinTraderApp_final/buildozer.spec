[app]
title = Bitpin Trader
package.name = bitpintrader
package.domain = com.majidmousavi

source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,json
source.exclude_exts = spec

version = 0.1

requirements = python3,kivy==2.3.1,requests>=2.32,<3

orientation = portrait
fullscreen = 0

android.api = 35
android.minapi = 23
android.archs = arm64-v8a,armeabi-v7a
android.permissions = INTERNET

[buildozer]
log_level = 2
warn_on_root = 1

[p4a]
# Keep python-for-android explicit instead of silently following master.
p4a.branch = master
