from .client import BitpinClient

class Market:
    def __init__(self):
        self.client = BitpinClient()

    def get_markets(self):
        return self.client.get_markets()

    def get_tickers(self):
        return self.client.get_tickers()
