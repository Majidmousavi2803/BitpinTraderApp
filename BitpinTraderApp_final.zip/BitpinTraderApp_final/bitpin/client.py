import os
import requests

class BitpinClient:
    BASE_URL = "https://api.bitpin.market/api/v1"

    def __init__(self):
        self.api_key = os.getenv("BITPIN_API_KEY")
        self.secret_key = os.getenv("BITPIN_SECRET_KEY")
        self.access_token = None

    def get_markets(self):
        r = requests.get(f"{self.BASE_URL}/mkt/markets/", timeout=15)
        r.raise_for_status()
        return r.json()

    def get_tickers(self):
        r = requests.get(f"{self.BASE_URL}/mkt/tickers/", timeout=15)
        r.raise_for_status()
        return r.json()
